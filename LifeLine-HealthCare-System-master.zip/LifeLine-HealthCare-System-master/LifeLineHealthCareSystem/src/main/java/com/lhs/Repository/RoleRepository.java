package com.lhs.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lhs.Models.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

	

}
